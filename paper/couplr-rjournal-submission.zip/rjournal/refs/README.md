# Comparator corpus

Thirteen published R Journal contributed research articles, used to calibrate
the writing of `../rjournal.Rmd`. Not part of the submission: this directory is
gitignored so it cannot be swept into the 10 MB submission archive.

All are CC BY, downloaded from `https://journal.r-project.org/articles/<ID>/<ID>.pdf`.
`txt/` holds the extracted text the metrics script reads.

| ID | Package | Selected for |
|---|---|---|
| RJ-2011-015 | Ckmeans.1d.dp | exact algorithm replacing a heuristic, runtime comparison |
| RJ-2018-009 | sf | replaces an incumbent package family |
| RJ-2019-005 | rollmatch | matching design, step-by-step walkthrough |
| RJ-2019-018 | CMatching | dedicated "existing R packages" section |
| RJ-2021-063 | stratamatch | scaling optimal matching to large samples |
| RJ-2021-073 | MatchThem | interoperability with other matching packages |
| RJ-2022-011 | PSweight | large design-plus-analysis platform paper |
| RJ-2024-013 | DoE | survey of a package ecosystem |
| RJ-2024-021 | pomdp | solver infrastructure over an external solver |
| RJ-2024-041 | GPUmatrix | backend swap with a performance-comparison section |
| RJ-2025-017 | rqPen | many penalties behind one interface, plus simulations |
| RJ-2025-045 | ASML | algorithm selection from a portfolio |
| RJ-2026-013 | atime | benchmarking methodology, "Related work" section |

## Regenerate

```bash
S=~/.claude/skills/r-journal/references
python $S/rj_style_metrics.py --pull refs --extract refs
python $S/rj_style_metrics.py --corpus refs/txt --draft rjournal.Rmd
```

Findings from the 2026-08-09 run, and the register conventions they support,
are written up in `$S/writing-style.md`.
